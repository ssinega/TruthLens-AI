"""
TruthLens — utils package init
"""
